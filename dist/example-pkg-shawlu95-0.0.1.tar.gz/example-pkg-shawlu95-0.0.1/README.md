# Packaging Tutorial
* Author: https://github.com/shawlu95
* Project: https://github.com/shawlu95/packaging_tutorial
* Tutorial: https://packaging.python.org/tutorials/packaging-projects/